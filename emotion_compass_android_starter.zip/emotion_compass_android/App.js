import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, TextInput, StyleSheet, ScrollView, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { feelings } from './data/feelings';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function FeelingsHome({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>How are you feeling?</Text>
      <Text style={styles.subtitle}>Tap a feeling to learn what it may be trying to tell you.</Text>
      <FlatList
        data={feelings}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={{ paddingBottom: 20 }}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('FeelingDetail', { feelingId: item.id })}>
            <Text style={styles.emoji}>{item.emoji}</Text>
            <Text style={styles.cardTitle}>{item.name}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

function FeelingDetail({ route }) {
  const feeling = feelings.find(f => f.id === route.params.feelingId);
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.bigEmoji}>{feeling.emoji}</Text>
      <Text style={styles.title}>{feeling.name}</Text>
      <Text style={styles.sectionTitle}>What it may mean</Text>
      <Text style={styles.body}>{feeling.meaning}</Text>
      <Text style={styles.sectionTitle}>What it may be asking from you</Text>
      <Text style={styles.body}>{feeling.message}</Text>
      <Text style={styles.sectionTitle}>Reflection questions</Text>
      {feeling.questions.map((q, index) => (
        <Text key={index} style={styles.question}>• {q}</Text>
      ))}
      <Text style={styles.note}>This app is for reflection and education. It is not medical or mental health treatment.</Text>
    </ScrollView>
  );
}

function FeelingsStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="FeelingsHome" component={FeelingsHome} options={{ title: 'Emotion Compass' }} />
      <Stack.Screen name="FeelingDetail" component={FeelingDetail} options={{ title: 'Feeling Meaning' }} />
    </Stack.Navigator>
  );
}

function JournalScreen() {
  const [entry, setEntry] = useState('');
  const [entries, setEntries] = useState([]);

  useEffect(() => { loadEntries(); }, []);

  async function loadEntries() {
    const saved = await AsyncStorage.getItem('journalEntries');
    if (saved) setEntries(JSON.parse(saved));
  }

  async function saveEntry() {
    if (!entry.trim()) {
      Alert.alert('Add a journal entry first.');
      return;
    }
    const newEntry = { id: Date.now().toString(), text: entry, date: new Date().toLocaleString() };
    const updated = [newEntry, ...entries];
    setEntries(updated);
    setEntry('');
    await AsyncStorage.setItem('journalEntries', JSON.stringify(updated));
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Journal</Text>
      <Text style={styles.subtitle}>Write what happened, what you felt, and what you need.</Text>
      <TextInput
        style={styles.input}
        multiline
        placeholder="Today I feel..."
        value={entry}
        onChangeText={setEntry}
      />
      <TouchableOpacity style={styles.button} onPress={saveEntry}>
        <Text style={styles.buttonText}>Save Entry</Text>
      </TouchableOpacity>
      {entries.map(e => (
        <View key={e.id} style={styles.entry}>
          <Text style={styles.entryDate}>{e.date}</Text>
          <Text style={styles.body}>{e.text}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

function CalmScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Calm Tools</Text>
      <Text style={styles.sectionTitle}>Box Breathing</Text>
      <Text style={styles.body}>Breathe in for 4 seconds. Hold for 4. Breathe out for 4. Hold for 4. Repeat 4 times.</Text>
      <Text style={styles.sectionTitle}>5-4-3-2-1 Grounding</Text>
      <Text style={styles.question}>• Name 5 things you can see.</Text>
      <Text style={styles.question}>• Name 4 things you can feel.</Text>
      <Text style={styles.question}>• Name 3 things you can hear.</Text>
      <Text style={styles.question}>• Name 2 things you can smell.</Text>
      <Text style={styles.question}>• Name 1 thing you can taste.</Text>
      <Text style={styles.sectionTitle}>Crisis Support</Text>
      <Text style={styles.body}>If you might hurt yourself or someone else, call emergency services now. In the U.S., call or text 988 for the Suicide & Crisis Lifeline.</Text>
    </ScrollView>
  );
}

function AboutScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>About Emotion Compass</Text>
      <Text style={styles.body}>Emotion Compass helps you slow down and understand what your feelings may mean. Feelings are signals, not enemies.</Text>
      <Text style={styles.note}>Disclaimer: This app does not diagnose or treat mental health conditions. For serious or ongoing concerns, talk with a licensed professional.</Text>
    </ScrollView>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="dark" />
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarActiveTintColor: '#6B4EFF',
          tabBarInactiveTintColor: '#777',
          tabBarIcon: ({ color, size }) => {
            const icons = { Feelings: 'heart-outline', Journal: 'book-outline', Calm: 'leaf-outline', About: 'information-circle-outline' };
            return <Ionicons name={icons[route.name]} size={size} color={color} />;
          },
        })}
      >
        <Tab.Screen name="Feelings" component={FeelingsStack} />
        <Tab.Screen name="Journal" component={JournalScreen} />
        <Tab.Screen name="Calm" component={CalmScreen} />
        <Tab.Screen name="About" component={AboutScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F7F3EA', padding: 20 },
  title: { fontSize: 30, fontWeight: '800', color: '#242038', marginBottom: 8 },
  subtitle: { fontSize: 16, color: '#5F5A6B', marginBottom: 20, lineHeight: 23 },
  card: { backgroundColor: '#FFFFFF', width: '47%', margin: '1.5%', padding: 20, borderRadius: 20, minHeight: 130, justifyContent: 'center', alignItems: 'center', elevation: 2 },
  emoji: { fontSize: 38, marginBottom: 8 },
  bigEmoji: { fontSize: 70, textAlign: 'center', marginTop: 10 },
  cardTitle: { fontSize: 18, fontWeight: '700', color: '#242038' },
  sectionTitle: { fontSize: 20, fontWeight: '800', color: '#242038', marginTop: 22, marginBottom: 8 },
  body: { fontSize: 16, color: '#343044', lineHeight: 24 },
  question: { fontSize: 16, color: '#343044', lineHeight: 26, marginBottom: 5 },
  note: { backgroundColor: '#FFF6D8', color: '#5E4A00', padding: 14, borderRadius: 14, marginTop: 24, lineHeight: 22 },
  input: { minHeight: 140, backgroundColor: '#FFFFFF', borderRadius: 16, padding: 14, fontSize: 16, textAlignVertical: 'top', marginBottom: 14 },
  button: { backgroundColor: '#6B4EFF', padding: 15, borderRadius: 14, alignItems: 'center', marginBottom: 20 },
  buttonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '800' },
  entry: { backgroundColor: '#FFFFFF', padding: 15, borderRadius: 16, marginBottom: 12 },
  entryDate: { color: '#777', marginBottom: 8, fontSize: 12 }
});
