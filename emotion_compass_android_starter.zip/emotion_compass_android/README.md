# Emotion Compass Android App

A simple Android starter app that helps users understand feelings and what they may mean.

## Features
- Feelings library
- Feeling detail pages
- Reflection questions
- Journal entries saved on device
- Calm tools
- Crisis support disclaimer page

## How to run
1. Install Node.js
2. Install Expo: `npm install -g expo-cli`
3. Open this folder in a terminal
4. Run: `npm install`
5. Run: `npm start`
6. Scan the QR code with the Expo Go app on Android

## Google Play Store
To publish, create a Google Play Developer account, then build the Android app using Expo EAS Build.
