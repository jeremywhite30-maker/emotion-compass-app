export const feelings = [
  {
    id: 'anger',
    name: 'Anger',
    emoji: '🔥',
    meaning: 'Anger can mean something feels unfair, unsafe, disrespectful, or out of your control.',
    message: 'It may be asking you to slow down, protect a boundary, or speak up in a healthy way.',
    questions: [
      'What happened right before I felt angry?',
      'Did I feel hurt, embarrassed, ignored, or disrespected?',
      'What boundary might I need to protect?'
    ]
  },
  {
    id: 'sadness',
    name: 'Sadness',
    emoji: '🌧️',
    meaning: 'Sadness can mean you lost something important, feel disappointed, or need comfort.',
    message: 'It may be asking you to rest, grieve, talk to someone safe, or care for yourself.',
    questions: [
      'What am I missing or grieving?',
      'What do I need right now?',
      'Who could I talk to safely?'
    ]
  },
  {
    id: 'anxiety',
    name: 'Anxiety',
    emoji: '⚡',
    meaning: 'Anxiety can mean your mind is trying to protect you from danger, uncertainty, or overwhelm.',
    message: 'It may be asking you to slow down, prepare, breathe, or take one small step.',
    questions: [
      'What am I worried might happen?',
      'Is this danger happening now, or is it a future fear?',
      'What is one small step I can take?'
    ]
  },
  {
    id: 'guilt',
    name: 'Guilt',
    emoji: '🧭',
    meaning: 'Guilt can mean your actions may not match your values.',
    message: 'It may be asking you to repair something, apologize, or make a better choice next time.',
    questions: [
      'Did I actually do something wrong?',
      'Is there something I need to repair?',
      'What lesson can I take from this?'
    ]
  },
  {
    id: 'shame',
    name: 'Shame',
    emoji: '🫥',
    meaning: 'Shame can make you feel like something is wrong with you, not just what happened.',
    message: 'It may be asking for compassion, honesty, and connection with someone safe.',
    questions: [
      'Am I judging myself too harshly?',
      'What would I say to a friend feeling this way?',
      'Who helps me feel accepted?'
    ]
  },
  {
    id: 'loneliness',
    name: 'Loneliness',
    emoji: '🌙',
    meaning: 'Loneliness can mean you need connection, belonging, or to feel understood.',
    message: 'It may be asking you to reach out, join something, or be honest about needing support.',
    questions: [
      'Do I need company, understanding, or reassurance?',
      'Who is one person I can contact?',
      'What place helps me feel connected?'
    ]
  },
  {
    id: 'jealousy',
    name: 'Jealousy',
    emoji: '👀',
    meaning: 'Jealousy can point to fear of loss, insecurity, comparison, or an unmet need.',
    message: 'It may be asking you to understand what you value and communicate honestly.',
    questions: [
      'What am I afraid of losing?',
      'What need is underneath this feeling?',
      'Am I comparing myself unfairly?'
    ]
  },
  {
    id: 'numbness',
    name: 'Numbness',
    emoji: '🧊',
    meaning: 'Numbness can happen when emotions feel too big or your system needs a break.',
    message: 'It may be asking for safety, rest, grounding, and gentle support.',
    questions: [
      'What might I be avoiding because it feels too heavy?',
      'What helps me feel safe in my body?',
      'Can I name one tiny feeling right now?'
    ]
  }
];
